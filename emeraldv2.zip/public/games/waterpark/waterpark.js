/*
Seriously, go here: https://www.khanacademy.org/computer-programming/marble-machine-interactive/6736338681282560
It is a lot better than this and has 50X better collisions.

Left click to place blocks, right click to remove blocks. Simple.
Uh, I guess have fun?
Design something cool.
Press "S" to get savecode.
HOT LIST FIRST PAGE YAY!
Note: savecode won't work. Trying to fix that this instant.
Savecode fixed!
Space to start/stop water.
Space now makes water dissapear. 
*/
//Sound. Very rigged. Use at your own risk.
var sound = false;
//Savecode: {
var blocks = [];
//}

frameRate(30);
//Change this for amount of water.
var amount_of_water = 5;
var water = [];
var bouncy = 0.5;
noCursor();
var collide = function(x1, y1, x2, y2, vx, vy, s1, s2) {
    //_clearLogs();
    var a = (x1 - x2) / (y1 - y2);
    var v1x = (a * vy + a * a * vx) / (a * a + 1);
    var v1y = (vy + a * vx) / (a * a + 1);
    var v2x = (vx - a * vy) / (a * a + 1);
    var v2y = (a * a * vy - a * vx) / (a * a + 1);
    //println(vx + "\n" + vy);
    //return [vx, vy];
    return [(-v1x + v2x), (-v1y + v2y)];
};
draw = function() {
    background(200, 200, 200);
    for(var i = 0; i < amount_of_water; i++) {
        water.push([random(0, 400), random(-1, 1), 0, 1, 1000]);
    }
    //fill(255, 0, 0, 62.5);
    noStroke();
    for(var i = 0; i < water.length; i++) {
        //fill(random(0, 255), random(0, 255), random(0, 255));
        fill(0, 200, 255, water[i][4]/1000*127.5);
        ellipse(water[i][0], water[i][1], 5, 5);
        water[i][0] += water[i][2];
        water[i][1] += water[i][3];
        water[i][2] *= 0.99;
        water[i][3] *= 0.99;
        water[i][3] += 0.1;
        if(water[i][0] >= 400) {
            water[i][0] = 400;
            water[i][2] = -abs(water[i][2])*bouncy;
        }
        if(water[i][0] <= 0) {
            water[i][0] = 0;
            water[i][2] = abs(water[i][2])*bouncy;
        }
        if(water[i][1] <= 0) {
            water[i][1] = 0;
            water[i][3] = abs(water[i][3])*bouncy;
        }
        /*
        if(i !== 0) {
            stroke(0, 200, 255);
            strokeWeight(2.5);
            line(water[i][0], water[i][1], water[i-1][0], water[i-1][1]);
            noStroke();
        }
        */
        water[i][4]--;
        if(water[i][4] <= 0) {
            water.splice(i, 1);
        }
        if(water[i][1] >= 400) {
            water.splice(i, 1);
        }
    }
    
    fill(100, 100, 100);
    for(var i = 0; i < blocks.length; i+=2) {
        ellipse(blocks[i], blocks[i+1], 12.5, 12.5);
    }
    for(var i = 0; i < blocks.length; i+=2) {
        if(mouseIsPressed & mouseButton === RIGHT) {
            if(round(mouseX/12.5)*12.5 === blocks[i] & round(mouseY/12.5)*12.5 === blocks[i+1]) {
                blocks.splice(i, 2);
                break;
            }
        }
    }
    for(var i = 0; i < blocks.length; i+=2) {
        for(var j = 0; j < blocks.length; j+=2) {
            if(blocks[i] === blocks[j] & blocks[i+1] === blocks[j+1] & i !== j) {
                blocks.splice(i, 2);
            }
        }
    }
    for(var j = 0; j < water.length; j++) {
        for(var i = 0; i < blocks.length; i+=2) {
            var bloob = false;
            if(dist(blocks[i], blocks[i+1], water[j][0], water[j][1]) <= 8.75) {
                var col = collide(water[j][0], water[j][1], blocks[i], blocks[i+1], water[j][2], water[j][3], 12.5, 5);
                water[j][2] = col[0];
                water[j][3] = col[1];
                bloob = true;
                if(sound === true) {
                    playSound(getSound("retro/hit1"));
                }
            }
            while(dist(blocks[i], blocks[i+1], water[j][0], water[j][1]) <= 8.75) {
                water[j][0] += water[j][2];
                water[j][1] += water[j][3];
            }
            if(bloob === true) {
                break;
            }
        }
    }
    for(var j = 0; j < water.length; j++) {
        var blab = false;
        if(dist(round(mouseX/12.5)*12.5, round(mouseY/12.5)*12.5, water[j][0], water[j][1]) <= 8.75) {
            var colo = collide(water[j][0], water[j][1], mouseX, mouseY, water[j][2], water[j][3], 12.5, 5);
            water[j][2] = colo[0];
            water[j][3] = colo[1];
            blab = true;
        }
        while(dist(round(mouseX/12.5)*12.5, round(mouseY/12.5)*12.5, water[j][0], water[j][1]) <= 8.75) {
            water[j][0] += water[j][2];
            water[j][1] += water[j][3];
        }
    }
    if(mouseIsPressed & mouseButton === LEFT) {
        blocks.push(round(mouseX/12.5)*12.5, round(mouseY/12.5)*12.5);
    }
    fill(100, 100, 100, 30);
    for(var i = 0; i < blocks.length; i += 2) {
        if(round(mouseX/12.5)*12.5 === blocks[i] & round(mouseY/12.5)*12.5 === blocks[i+1]) {
            fill(255, 0, 0, 200);
        }
    }
    strokeWeight(2.5);
    stroke(0, 0, 0);
    ellipse(round(mouseX/12.5)*12.5, round(mouseY/12.5)*12.5, 12.5, 12.5);
};
keyReleased = function() {
    if(String(key) === "s") {
        _clearLogs();
        println("Copy and paste this into the savecode: \n\n"+"var blocks = ["+blocks+"];");
    }
    if(String(key) === " ") {
        for(var i = 0; i < water.length; i++) {
            water.splice(i);
        }
        amount_of_water = 5-amount_of_water;
    }
};